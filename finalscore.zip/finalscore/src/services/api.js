import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:3002/api',
  timeout: 15000,
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('finalscore-token');
  if (token) {
    config.headers = config.headers || {};
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error?.response?.status === 401) {
      localStorage.removeItem('finalscore-token');
      localStorage.removeItem('finalscore-user');
    }
    return Promise.reject(error);
  },
);

export default api;
